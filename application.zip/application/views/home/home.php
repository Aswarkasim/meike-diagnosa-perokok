<style>
    .bg-img-wrapper {
        width: 100%;
        height: 550px;
        overflow: hidden;
        position: absolute;
    }

    .bg-img {
        width: 100%;

    }

    .selamat-datang {
        position: relative
    }
</style>

<div class="bg-img-wrapper">
    <img src="<?= base_url('assets/img/bg.jpg'); ?>" class="bg-img" alt="">
</div>
<section class="content">
    <div class="error-page">

        <div class="error-content selamat-datang">
            <strong>
                <h1>
                    SELAMAT DATANG
                    SISTEM PAKAR DIAGNOSA PENYAKIT PADA PEROKOK
                </h1>
            </strong>
            </form>
        </div>
        <!-- /.error-content -->
    </div>
    <!-- /.error-page -->
</section>
</div>