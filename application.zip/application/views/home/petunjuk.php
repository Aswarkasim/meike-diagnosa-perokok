<div class="container-fluid">
    <div class="row">
        <div class="col-md-7">
            <h1><strong>PETUNJUK PENGUNNAAN</strong></h1>
            <p>
            1. Jawab pertanyaan sesuai yang anda alami <br>
            2. Jika anda menjawab YA maka akan muncul pernyataan/pertanyaan berikutnya <br>
            3. Jika anda menjawab TIDAK maka akan muncul pernyataan/pertanyaan berikutnya <br>
            4. Jawab semua pertanyaan untuk menampilkan hasil <br>
            5. Setelah menjawab semua pertanyaan maka akan muncul tampilan nama penyakit,deskripsi,akibat serta penanganannya
            </p>
        </div>
    </div>
</div>