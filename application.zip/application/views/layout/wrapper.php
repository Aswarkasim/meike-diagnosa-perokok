<?php require_once('head.php') ?>
<?php require_once('header.php') ?>
<?php require_once('nav.php') ?>
<?php require_once('content.php') ?>
<?php require_once('footer.php') ?>