<div class="row">

  <div class="col-md-6">

    <div class="box">
      <div class="box-header">
        <h3 class="box-title"></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body no-padding">

        <div class="container-fluid">



        </div>
      </div>
      <!-- /.box-body -->
    </div>


  </div>
</div>